// With JQuery
$('#ex1').slider({
	formatter: function(value) {
		return 'Current value: ' + value;
	}
});

$('#ex2').slider({
	formatter: function(value) {
		return 'Current value: ' + value;
	}
});



$('#ex3').slider({
	formatter: function(value) {
		return 'Current value: ' + value;
	}
});


// With JQuery
$("#ex4").slider({
	reversed : true
});


// With JQuery
$("#ex5").slider({
	reversed : true
});

// With JQuery
$("#ex6").slider({
	reversed : true
});


// With JQuery
$("#ex7").slider({
	reversed : true
});


// With JQuery
$("#ex8").slider({
	reversed : true
});


// With JQuery
$("#ex9").slider({
	reversed : true
});